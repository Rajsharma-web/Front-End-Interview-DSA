import './App.css';
import  DebounceSearch  from './components/DebounceSearch/DebounceSearch';

function App() {
  return (
    <>
      <DebounceSearch />
    </>
  );
}

export default App;
