import Products from '../components/Products';

export default function ProductListing() {
  return (
    <div>
      <Products />
    </div>
  );
}
