import "./styles.css";
import CartPage from "./pages/CartPage";

export default function App() {
  return (
    <div className="App">
      <CartPage />
    </div>
  );
}
