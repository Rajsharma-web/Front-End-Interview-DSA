<h1 align ="center">DAILY BYTES ⚡⏩👨‍💻</h1>

<img src="https://i.insider.com/5c38e724aebf4216042766cc?width=1000&format=jpeg&auto=webp" align="left" width="50%">

This repository contains all the popular competitive programming questions and interview questions. The main aim of the repository is help many other students that are prepare for interview this contains various questions of Hackerank, Codechef Data Strctures and Algorithms etc.

Simple if you practice on online judges like codechef or any other like Geeks for Geeks you can add questions on this repository. This repository contains all important problems that appeared Facebook, Amazon, and Google interviews.