<h1 align="center">Week 2</h1>

### [Bubble Sort an Array](https://www.geeksforgeeks.org/bubble-sort/)

### [Selection Sort in an Array](https://www.geeksforgeeks.org/selection-sort/)


### [Insertion Sort in an Array](https://www.geeksforgeeks.org/insertion-sort/)

### [Merge Sort in An Array](https://www.geeksforgeeks.org/merge-sort/)

### [Quick Sort in an Array.](https://www.geeksforgeeks.org/quick-sort/)

### [Sorting of array consisting of Element 0s,1s,2s only](https://www.geeksforgeeks.org/sort-an-array-of-0s-1s-and-2s/)



Medium
Given an array which consists of 0,1 and 2 only. Sort the array wwithout any sorting algo.
Move all the negative elements to one side of the array.
Find the union and intersection of two sorted arrays.