Solutions to problems on [HackerRanK](https://www.hackerrank.com/)

<div align="center">
<img src="https://upload.wikimedia.org/wikipedia/commons/4/40/HackerRank_Icon-1000px.png" width="50%" float="center" >
</div>

