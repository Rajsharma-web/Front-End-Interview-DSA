var findMin = function(nums) {
    return Math.min(...nums)
};