## Bit Manipulation 

[Bit Manipulation: Interview Questions and Practice Problems](https://medium.com/techie-delight/bit-manipulation-interview-questions-and-practice-problems-27c0e71412e7)