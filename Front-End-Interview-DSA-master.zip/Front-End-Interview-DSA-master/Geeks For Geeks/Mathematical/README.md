# Mathematical Algorithms 🧮

<p align ="center"><img src ="https://user-images.githubusercontent.com/61475220/92311608-173af100-efd6-11ea-91a6-f897c52f2dff.jpg" width="700px"></p>

## Prime Factorization :

Following are the steps to find all prime factors.
1) While n is divisible by 2, print 2 and divide n by 2.
2) After step 1, n must be odd. Now start a loop from i = 3 to square root of n. While i divides n, print i and divide n by i. After i fails to divide n, increment i by 2 and continue.
3) If n is a prime number and is greater than 2, then n will not become 1 by above two steps. So print n if it is greater than 2.
